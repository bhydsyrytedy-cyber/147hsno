# 147hsno

Static site (no build step). Files:

- `index.html` - the page
- `assets/bg.mp4` - background video
- `assets/music.m4a` - background music (loops seamlessly)

## Publish on GitHub Pages

1. Create a new repository on GitHub and upload all files, keeping the `assets` folder.
2. Open **Settings > Pages**, set **Source** to "Deploy from a branch", choose branch `main` and folder `/ (root)`, then Save.
3. After a minute the site is live at `https://<username>.github.io/<repo-name>/`.

For the address `https://147hsno.github.io/`, the GitHub account must be named `147hsno` and the repository must be named `147hsno.github.io`.

Note: open the site through the GitHub Pages link, not by double-clicking `index.html`, otherwise the browser blocks loading the music.
